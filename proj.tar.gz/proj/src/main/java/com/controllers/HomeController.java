package com.controllers;

import java.util.Iterator;
import java.util.List;

import javax.xml.crypto.Data;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import data.*;
@Controller
public class HomeController {
	/*
	 * To Have List Of all items which are sold by a particular seller
	 * 
	 * 
	 */
	
	public List<Object> getItems(String s_id) {
		
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory SF =con.buildSessionFactory(); 
		Session session=SF.openSession();	
		Query qry= session.createQuery("select i.id, i.desc,i.quantity from DataProviderCustomer c Inner Join c.items i where i.seller_id='"+s_id +"'"); 
		List l = qry.list();
		//For Displaying On Console
		//	Iterator it=l.iterator();
		/*while(it.hasNext())
		{
			Object rows[] = (Object[])it.next();
			System.out.println(rows[0]+ " -- " +rows[1]);
		}
		*/		
		session.close();
		SF.close();
		return l;
	}
	
	/*
	 * Get list of All items Available for a buyer to be purchased
	 * 
	 * 
	 */
	
	public List<Object> getSellableItems() {
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory SF =con.buildSessionFactory(); 
		Session session=SF.openSession();	
		Query qry= session.createQuery("select i.id,i.desc,i.quantity,i.price,i.category from DataProviderItems i"); 
		List l = qry.list();				
		session.close();
		SF.close();
		return l;
	}
	
	/*
	 * 
	 * To Get List of All items Which a Buyer has purchased
	 */

	public List<Object> getPurchasedItems(String c_id) {
		
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory SF =con.buildSessionFactory(); 
		Session session=SF.openSession();	
		Query qry= session.createQuery("select i.desc,sum(io.quantity) from DataProviderItems i, DataProviderPurchase io where i.id=io.item_id and io.buyer_id='"+c_id+"' group by i.desc"); 
		List l = qry.list();
		session.close();
		SF.close();
		return l;
	}
	
	/*
	 * 
	 * Function Which tells weather the Given Id of user belongs to a buyer or a seller/buyer  
	 */
	
	
	public boolean isSeller(String id)
	{
		boolean isSellerFlag=false;
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory SF =con.buildSessionFactory(); 
		Session session=SF.openSession();
		Object ob = session.load(data.DataProviderCustomer.class,new String(id));
		DataProviderCustomer DP = (DataProviderCustomer) ob;
		isSellerFlag=DP.isIs_seller();
		System.out.println(isSellerFlag);
		session.close();
		SF.close();
		return isSellerFlag;
	}	
	
	/*
	 * 
	 * Mapping which Performs the function of differentiating between a buyer and a seller after taking username
	 */
	
	@RequestMapping(value="/home")
	public ModelAndView home(@RequestParam String uname){
		boolean is_seller=false;
		is_seller = isSeller(uname);
		ModelAndView mbuyer=new ModelAndView("buyer");
		mbuyer.addObject("uname",uname);
		List l= getSellableItems();
		List itemsPurchased =getPurchasedItems(uname); 
		mbuyer.addObject("itemsToBeSold",l);
		mbuyer.addObject("itemsPurchased",itemsPurchased);
		String name=DataProviderCustomer.getName(uname);
		mbuyer.addObject("cust_name",name);
		
		if(is_seller)
			return new ModelAndView("option","uname",uname);
		else
				return mbuyer;
			
	}
	
	/*
	 * 
	 * Mapping which Generates Buyer or seller page based on user choice if the user is buyer/seller.
	 */
	
	@RequestMapping(value="/option/check")
	public ModelAndView option(@RequestParam String selectedOption, @RequestParam String uname)
	{
		List l =getItems(uname);
		ModelAndView m=new ModelAndView("seller");
		m.addObject("itemsSold",l);
		m.addObject("uname",uname);
		String name=DataProviderCustomer.getName(uname);
		m.addObject("cust_name",name);
		if(selectedOption.equals("Buyer"))
		{
			ModelAndView mbuyer=new ModelAndView("buyer");
			mbuyer.addObject("uname",uname);
			List l1= getSellableItems();
			List itemsPurchased =getPurchasedItems(uname); 
			mbuyer.addObject("itemsToBeSold",l1);
			mbuyer.addObject("itemsPurchased",itemsPurchased);
			String name1=DataProviderCustomer.getName(uname);
			mbuyer.addObject("cust_name",name1);
			return mbuyer;
			
		}else
			return m;
	}		
	
	
	/*
	 * Mapping to launch a new page which prompts a seller to enter new items to be sold 
	 * 
	 */
	@RequestMapping(value="/option/addItems")
	public ModelAndView addItems(@RequestParam String uname)
	{
		return new ModelAndView("addItems","uname",uname);
	}
	@RequestMapping(value="/option/add")
	public ModelAndView add(@RequestParam String desc,@RequestParam String cat,@RequestParam int quantity,@RequestParam int price, @RequestParam String uname)
	{
		DataProviderItems item = new DataProviderItems();
		
		item.setCategory(cat);
		item.setDesc(desc);
		item.setPrice(price);
		item.setQuantity(quantity);
		item.setSeller_id(uname);
		item.saveItem();
		List l =getItems(uname);
		ModelAndView m=new ModelAndView("seller");
		m.addObject("itemsSold",l);
		m.addObject("uname",uname);
		String name=DataProviderCustomer.getName(uname);
		m.addObject("cust_name",name);
		return m;
	}
	/*
	 * 
	 * Mapping which Prompts a buyer to purchase products
	 */
	
	@RequestMapping(value={"/buy","/option/buy"})
	public ModelAndView buy(@RequestParam String uname,@RequestParam int item_id,@RequestParam int quantity)
	{
		DataProviderPurchase Order= new DataProviderPurchase();
		Order.setItem_id(item_id);
		Order.setBuyer_id(uname);
		Order.setQuantity(quantity);
		boolean r=Order.saveOrder();
		List l =getSellableItems();
		List l2 =getPurchasedItems(uname);
		ModelAndView m=new ModelAndView("buyer");
		m.addObject("itemsToBeSold",l);
		m.addObject("itemsPurchased",l2);
		m.addObject("uname",uname);
		String name=DataProviderCustomer.getName(uname);
		m.addObject("cust_name",name);
		m.addObject("result",r);
		return m;
	}
	
	/*
	 * Mapping Which Prompts a seller to add quantity to existing items.
	 */
	
	@RequestMapping(value="/option/more")
	public ModelAndView more(@RequestParam String uname,@RequestParam int item_id,@RequestParam int quantity)
	{
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory SF =con.buildSessionFactory(); 
		Session session=SF.openSession();	
		Object ob=session.load(DataProviderItems.class, new Integer(item_id));
		DataProviderItems item=(DataProviderItems)ob;
		Transaction tx = session.beginTransaction();
		item.setQuantity(item.getQuantity()+quantity);
		tx.commit();
		session.close();
		List l =getItems(uname);
		ModelAndView m=new ModelAndView("seller");
		m.addObject("itemsSold",l);
		m.addObject("uname",uname);
		String name=DataProviderCustomer.getName(uname);
		m.addObject("cust_name",name);
		return m;
	}
}
