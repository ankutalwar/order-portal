//DAO For Customer.

package data;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class DataProviderCustomer {
	private String uname;
	private String cust_name;
	private boolean is_seller;
	private Set items;  
	private Set purchase;
	public Set getPurchase() {
		return purchase;
	}
	public void setPurchase(Set purchase) {
		this.purchase = purchase;
	}
	public Set getItems() {
		return items;
	}
	public void setItems(Set items) {
		this.items = items;
	}
	
	public String getuname() {
		return uname;
	}
	public void setuname(String uname) {
		this.uname = uname;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public boolean isIs_seller() {
		return is_seller;
	}
	public void setIs_seller(boolean is_seller) {
		this.is_seller = is_seller;
	}
	
	/*
	 * 
	 * REturn the Name of user by a username.
	 */
	public static String getName(String c_id)
	{
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory SF =con.buildSessionFactory(); 
		Session session=SF.openSession();	
		Query qry=session.createQuery("select cust_name from DataProviderCustomer where uname ='"+c_id+"'");
		List <String> name=qry.list();
		System.out.println(name);
		session.close();
		SF.close();
		return name.get(0);
		//return name;
	}
	

}
