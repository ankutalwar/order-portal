package data;
//DAO for Items.
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DataProviderItems {

	private int id;
	private String desc;
	private String category;
	private String seller_id;
	private int quantity;
	private int price;
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(String seller_id) {
		this.seller_id = seller_id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	/*
	 * 
	 * Saves Item object on Database
	 */
	
	public void saveItem() {
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory SF =con.buildSessionFactory(); 
		Session session=SF.openSession();	
		Transaction tx = session.beginTransaction();
		session.persist(this);
		tx.commit();
		session.close();
	}
	
	
	
}
