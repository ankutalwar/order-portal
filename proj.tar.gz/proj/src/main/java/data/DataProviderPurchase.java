package data;
//DAO for Orders.
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class DataProviderPurchase {

	private int id;
	private int item_id;
	private String buyer_id;
	private int quantity;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getItem_id() {
		return item_id;
	}
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	public String getBuyer_id() {
		return buyer_id;
	}
	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/* Save Orders On Database
	 * 
	 * 
	 */
	public boolean saveOrder() {
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory SF =con.buildSessionFactory(); 
		Session session=SF.openSession();	
		Object ob=session.load(DataProviderItems.class, new Integer(this.getItem_id()));
		DataProviderItems item=(DataProviderItems)ob;
		if(this.getQuantity()<=item.getQuantity())
		{
		Transaction tx = session.beginTransaction();
		session.persist(this);
		item.setQuantity(item.getQuantity()-this.getQuantity());
		tx.commit();
		session.close();
		return true;
		}
		else
			{
			System.out.println("Fail");
			return false;
			}
	}
}
