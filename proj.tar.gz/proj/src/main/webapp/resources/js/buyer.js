function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

	



$(document).ready(function(){
	  $('#keywords').tablesorter(); 
	});
	
	function showquantity(id)
	{
		$('#q'+id).show();
		$('#i'+id).replaceWith($('#q'+id));		
	}
	
function buyitems(id)
{
	var frm =$('#f'+id);
    $.ajax({
        type: frm.attr('method'),
        url:  frm.attr('action'),
        data: frm.serialize(),
        success: function(response) {
        	
        	
        	$("#items").replaceWith($($.parseHTML(response)).filter("#items"));
        	
        	var ip=$($.parseHTML(response)).filter("#ItemsPurchased");
        	
        	ip.css("display", "none");
        	$("#ItemsPurchased").replaceWith(ip);
        	$("#keywords").trigger("update");
        },
        error: function ()
        {
        	alert("Im failed");
        	
        }
    });
    
}	

