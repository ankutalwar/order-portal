function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();


function showquantity(id)
	{
		$('#q'+id).show();
		//$('#i'+id).attr('disabled','disabled');
		$('#i'+id).replaceWith($('#q'+id));
	}
	
	function sellitems(id)
	{
		var frm =$('#f'+id);
	    $.ajax({
	        type: frm.attr('method'),
	        url:  frm.attr('action'),
	        data: frm.serialize(),
	        success: function(response) {
	        	var is=$($.parseHTML(response)).filter("#items");
	        	is.css("display","block");
	        	
	        	$("#items").replaceWith(is);
	        },
	        error: function ()
	        {
	        	alert("Im failed");
	        	
	        }
	    });
		
	}	